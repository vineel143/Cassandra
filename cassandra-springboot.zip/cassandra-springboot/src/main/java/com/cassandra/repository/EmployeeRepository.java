package com.cassandra.repository;


import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.cassandra.repository.AllowFiltering;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;

import com.cassandra.model.Employee;
@EnableCassandraRepositories(basePackages = {"com.cassandra.*"})
public interface EmployeeRepository extends CassandraRepository<Employee, UUID> {
	
	 @Query(allowFiltering = true)
	  Optional<Employee> findById(UUID id);
	
	 @AllowFiltering
	  List<Employee> findByValid(boolean valid);

}
