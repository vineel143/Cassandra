package com.cassandra.model;

import java.util.UUID;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("employee")
public class Employee {

	@PrimaryKey
	private UUID id;

	@Column("name")
	private String name;

	@Column("age")
	private String age;

	@Column("valid")
	private boolean valid;

	public Employee(UUID id, String name, String age, boolean valid) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.valid = valid;

	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public boolean getValid() {
		return valid;
	}

	public void setValid(boolean valid) {
		this.valid = valid;
	}

}
